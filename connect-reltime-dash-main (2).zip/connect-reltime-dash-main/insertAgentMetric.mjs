import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { ConnectClient, ListQueuesCommand, GetCurrentUserDataCommand } from "@aws-sdk/client-connect";
import mysql from "mysql2/promise";

const secretName = process.env.SECRET_NAME;
const host = process.env.HOST;
const database = process.env.DATABASE;

const secretsManagerClient = new SecretsManagerClient({});
let secretResponse;

try {
  secretResponse = await secretsManagerClient.send(
    new GetSecretValueCommand({
      SecretId: secretName,
      VersionStage: "AWSCURRENT",
    })
  );
} catch (error) {
  console.error(`Error fetching secret: ${error}`);
  throw error;
}

const connectionSettings = JSON.parse(secretResponse.SecretString);
const secret = connectionSettings.password;
const user = connectionSettings.username;

const connectClient = new ConnectClient({});

export const insertAgentMetric = async (event) => {
  const connectionConfig = {
    host,
    user,
    password: secret,
    database,
  };

  try {
    const instanceId = event.InstanceId;
    let queueIds = [];

    const listQueuesParams = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      MaxResults: 1000,
    };
    const listQueuesCommand = new ListQueuesCommand(listQueuesParams);
    const listQueuesResponse = await connectClient.send(listQueuesCommand);
    const queues = listQueuesResponse.QueueSummaryList;

    for (let queue of queues) {
      queueIds.push(queue.Id);
    }

    const userParams = {
      InstanceId: instanceId,
      Filters: {
        Queues: queueIds,
      },
      MaxResults: 100,
    };

    const getCurrentUserDataCommand = new GetCurrentUserDataCommand(userParams);
    const metricData = await connectClient.send(getCurrentUserDataCommand);

    const metricResults = metricData.UserDataList;
    console.log(`metricResults: ${JSON.stringify(metricResults)}`);

    if (!metricResults || metricResults.length === 0) {
      return "No metric data found";
    }

    let query =
      "INSERT INTO userMetrics (RequestTimestamp, UserId, UserArn, RoutingProfileId, RoutingProfileArn, StatusStartTimestamp, StatusArn, StatusName, AvailableSlotsByChannelVoice, AvailableSlotsByChannelTask, AvailableSlotsByChannelChat, MaxSlotsByChannelVoice, MaxSlotsByChannelTask, MaxSlotsByChannel, ContactsContactId, ContactsChannel, ContactsInitiationMethod, ContactsAgentContactState, ContactsStateStartTimestamp, ContactsConnectedToAgentTimestamp, ContactsQueueId, ContactsQueueArn) VALUES ";

    let allValues = [];

    for (const result of metricResults) {
      const RequestTimestamp = new Date();
      const UserId = result.User?.Id || 0;
      const UserArn = result.User?.Arn || 0;
      const RoutingProfileId = result.RoutingProfile?.Id || 0;
      const RoutingProfileArn = result.RoutingProfile?.Arn || 0;
      const StatusStartTimestamp = result.Status?.StatusStartTimestamp || 0;
      const StatusArn = result.Status?.StatusArn || 0;
      const StatusName = result.Status?.StatusName || 0;
      const AvailableSlotsByChannelVoice = result.AvailableSlotsByChannel?.VOICE || 0;
      const AvailableSlotsByChannelTask = result.AvailableSlotsByChannel?.TASK || 0;
      const AvailableSlotsByChannelChat = result.AvailableSlotsByChannel?.CHAT || 0;
      const MaxSlotsByChannelVoice = result.MaxSlotsByChannel?.VOICE || 0;
      const MaxSlotsByChannelTask = result.MaxSlotsByChannel?.TASK || 0;
      const MaxSlotsByChannel = result.MaxSlotsByChannel?.CHAT || 0;

      const contacts = result.Contacts?.[0] || {};
      const ContactsContactId = contacts.ContactId || 0;
      const ContactsChannel = contacts.Channel || 0;
      const ContactsInitiationMethod = contacts.InitiationMethod || 0;
      const ContactsAgentContactState = contacts.AgentContactState || 0;
      const ContactsStateStartTimestamp = contacts.StateStartTimestamp || 0;
      const ContactsConnectedToAgentTimestamp = contacts.ConnectedToAgentTimestamp || 0;
      const ContactsQueueId = contacts.Queue?.Id || 0;
      const ContactsQueueArn = contacts.Queue?.Arn || 0;

      const rowValues = [
        RequestTimestamp,
        UserId,
        UserArn,
        RoutingProfileId,
        RoutingProfileArn,
        StatusStartTimestamp,
        StatusArn,
        StatusName,
        AvailableSlotsByChannelVoice,
        AvailableSlotsByChannelTask,
        AvailableSlotsByChannelChat,
        MaxSlotsByChannelVoice,
        MaxSlotsByChannelTask,
        MaxSlotsByChannel,
        ContactsContactId,
        ContactsChannel,
        ContactsInitiationMethod,
        ContactsAgentContactState,
        ContactsStateStartTimestamp,
        ContactsConnectedToAgentTimestamp,
        ContactsQueueId,
        ContactsQueueArn,
      ];

      console.log("RowValues ->", rowValues);

      allValues.push(rowValues);
    }

    const valuePlaceholders = allValues.map(() => "(?)").join(",");
    query += valuePlaceholders;

    console.log(`Inserting data: ${JSON.stringify(allValues)}`);
    const connection = await mysql.createConnection(connectionConfig);
    await connection.query(query, allValues);
    await connection.end();

    return "Data successfully inserted.";
  } catch (error) {
    console.error(`Error: ${error}`);
    throw error;
  }
};