import mysql from "mysql2/promise";
import {
  AthenaClient,
  StartQueryExecutionCommand,
  GetQueryExecutionCommand,
  GetQueryResultsCommand,
} from "@aws-sdk/client-athena";
import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";

const secret_name_target = "nonprod/cdtfa_wallboard_rds/mysql";
const secret_name_source = "qa/dbcredmysql";
const client = new SecretsManagerClient({
  region: "us-west-2",
});

const athenaClient = new AthenaClient({
  region: "us-west-2",
});

let response_target_db = "";
let response_source_db = "";

try {
  console.log("Getting secret_name_target");
  response_target_db = await client.send(
    new GetSecretValueCommand({
      SecretId: secret_name_target,
      VersionStage: "AWSCURRENT",
    })
  );
  console.log("Ended secret_name_target");
} catch (error) {
  console.log(`Error: ${error}`);
  throw error;
}

try {
  console.log("Getting secret_name_source");
  response_source_db = await client.send(
    new GetSecretValueCommand({
      SecretId: secret_name_source,
      VersionStage: "AWSCURRENT",
    })
  );
  console.log("Ended secret_name_source");
} catch (error) {
  console.log(`Error: ${error}`);
  throw error;
}

const connectionSettingTarget = JSON.parse(response_target_db.SecretString);
const secret_target = connectionSettingTarget.password;
const host_target = connectionSettingTarget.host;
const user_target = connectionSettingTarget.username;
const database_target = connectionSettingTarget.dbname;

const connectionSettingSource = JSON.parse(response_source_db.SecretString);
const secret_source = connectionSettingSource.password;
const host_source = connectionSettingSource.host;
const user_source = connectionSettingSource.username;
const database_source = connectionSettingSource.dbname;

export const queueMetricsExternal = async (event) => {
  const connetionConfigTarget = {
    host: host_target,
    user: user_target,
    password: secret_target,
    database: database_target,
    connectTimeout: 50000,
  };

  const connetionConfigSource = {
    host: host_source,
    user: user_source,
    password: secret_source,
    database: database_source,
    connectTimeout: 50000,
  };

  try {
    console.log("Connecting to connetionConfigSource");
    const connectionSource = await mysql.createConnection(
      connetionConfigSource
    );
    const [rows] = await connectionSource.execute(
      "select * from queueMetrics_external_source"
    );
    if (rows.length === 0) {
      return {
        statusCode: 404,
        body: "No data found in source table.",
      };
    }
    console.log("Ending connection to connetionConfigSource");
    await connectionSource.end();
    console.log("Connecting to connetionConfigTarget");
    const connectionTarget = await mysql.createConnection(
      connetionConfigTarget
    );
    console.log("Truncate Query Starts");
    const resultTruncate = await connectionTarget.execute(
      "TRUNCATE TABLE queueMetrics_external"
    );
    console.log("Truncate Query Ends and Insert Begins");
    for (const row of rows) {
      await connectionTarget.execute(
        "INSERT INTO queueMetrics_external (RequestTimestamp,QueueId,QueueName,AGENTS_AFTER_CONTACT_WORK,AGENTS_AVAILABLE,AGENTS_ERROR,AGENTS_NON_PRODUCTIVE,AGENTS_ON_CALL,AGENTS_ON_CONTACT,AGENTS_ONLINE,AGENTS_STAFFED,CONTACTS_IN_QUEUE,CONTACTS_SCHEDULED,OLDEST_CONTACT_AGE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
          row.RequestTimestamp,
          row.QueueId,
          row.QueueName,
          row.AGENTS_AFTER_CONTACT_WORK,
          row.AGENTS_AVAILABLE,
          row.AGENTS_ERROR,
          row.AGENTS_NON_PRODUCTIVE,
          row.AGENTS_ON_CALL,
          row.AGENTS_ON_CONTACT,
          row.AGENTS_ONLINE,
          row.AGENTS_STAFFED,
          row.CONTACTS_IN_QUEUE,
          row.CONTACTS_SCHEDULED,
          row.OLDEST_CONTACT_AGE,
        ]
      );
    }
    console.log("Starts Athena Query");
    const queryResults = await executeAthenaQuery();
    console.log("Athena Query Done -> ", JSON.stringify(queryResults));

    for (const row of queryResults.slice(1)) {
      const queueId = row.Data[0].VarCharValue;
      const totalCalls = parseInt(row.Data[1].VarCharValue, 10);
      const abandonedCalls = parseInt(row.Data[2].VarCharValue, 10);

      console.log("Starts Update Table");
      await updateDatabase(
        queueId,
        totalCalls,
        abandonedCalls,
        connectionTarget
      );
    }

    await connectionTarget.end();
    return {
      statusCode: 200,
      body: "Process sucessfully completed.",
    };
  } catch (error) {
    console.log(`Error: ${error}`);
    throw error;
  }
};

async function executeAthenaQuery() {
  const params = {
    QueryString: `SELECT SUBSTR(queue.arn,92,36) as QueueId, count(*) as TOTAL_CALLS, count_if(agent is null) as TOTAL_ABANDONED
                      FROM "cdtfaconnectqactr"."connect_ctr" 
                      WHERE queue is not null 
                      AND queue.arn not like '%agent%'
                      AND year = CAST(format_datetime(now(),'y') AS INT)
                      AND month = CAST(format_datetime(now(),'M') AS INT)
                      AND day = CAST(format_datetime(now(),'d') AS INT)
                      GROUP BY 1`,
    QueryExecutionContext: {
      Database: "cdtfaconnectqactr",
    },
    ResultConfiguration: {
      OutputLocation: "s3://athena-queryresult-cdtfa/athena/",
    },
  };

  const startQueryExecutionResponse = await athenaClient.send(
    new StartQueryExecutionCommand(params)
  );
  const queryExecutionId = startQueryExecutionResponse.QueryExecutionId;

  let status = "RUNNING";
  while (status === "RUNNING" || status === "QUEUED") {
    const queryExecutionResponse = await athenaClient.send(
      new GetQueryExecutionCommand({ QueryExecutionId: queryExecutionId })
    );
    status = queryExecutionResponse.QueryExecution.Status.State;
    if (status === "FAILED" || status === "CANCELLED") {
      throw new Error(
        `Query failed or was cancelled: ${queryExecutionResponse.QueryExecution.Status.StateChangeReason}`
      );
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }

  const queryResultsResponse = await athenaClient.send(
    new GetQueryResultsCommand({ QueryExecutionId: queryExecutionId })
  );
  return queryResultsResponse.ResultSet.Rows;
}

async function updateDatabase(
  queueId,
  totalCalls,
  abandonedCalls,
  connectionTarget
) {
  const sql = `UPDATE queueMetrics_external SET TOTAL_CALLS = ?, TOTAL_ABANDONED = ? WHERE QueueId = ?`;
  const [results] = await connectionTarget.execute(sql, [
    totalCalls,
    abandonedCalls,
    queueId,
  ]);
  console.log(
    `Updated database for QueueId: ${queueId}. Rows affected: ${results.affectedRows}`
  );
}
