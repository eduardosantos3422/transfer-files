import { listQueues } from './listQueues.mjs';
import { listAgents } from './listAgents.mjs';
import { listRoutingProfiles } from './listRoutingProfiles.mjs';
import { hierarchyGroup } from './hierarchyGroup.mjs';
import { insertAgentMetric } from './insertAgentMetric.mjs';
import { insertQueueMetric } from './insertQueueMetric.mjs';
// import { queueMetricsExternal } from './queueMetrics_external.mjs'


export const handler = async (event) => {
  let data = "Event started but was not concluded."

  if (event.Method === 'insertQueueMetric') {
    data = await insertQueueMetric(event);
  }
  
  if (event.Method === 'listQueues') {
    data = await listQueues(event);
  }

  if (event.Method === 'insertAgentMetric') {
    data = await insertAgentMetric(event);
  }
  
  if (event.Method === 'listAgents') {
    data = await listAgents(event);
  }

  if (event.Method === 'listRoutingProfiles') {
    data = await listRoutingProfiles(event);
  }

  if (event.Method === 'hierarchyGroup') {
    data = await hierarchyGroup(event);
  }

  // if (event.Method === 'queueMetricsExternal') {
  //   data = await queueMetricsExternal(event);
  // }

  return data;
};


