awsconnectmetrics.cneuiasnjkcd.us-west-2.rds.amazonaws.com

Pass HMSA  MZ#e>5|tA!s*M.:cagPWJCGt3p_B
# TABLES

```
-- awsconnectmetrics.listAgents definition

CREATE TABLE `listAgents` (
  `Id` varchar(100) NOT NULL,
  `Arn` varchar(250) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `UpdateTimestamp` datetime NOT NULL,
  `Firstname` varchar(100) DEFAULT NULL,
  `Lastname` varchar(100) DEFAULT NULL,
  `HierarchyGroupId` varchar(100) DEFAULT NULL,
  `RoutingProfileId` varchar(100) DEFAULT NULL,
  UNIQUE KEY `listAgents_Id_IDX` (`Id`,`Username`) USING BTREE,
  UNIQUE KEY `ksjdfhkjdfh` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.listQueues definition

CREATE TABLE `listQueues` (
  `Id` varchar(100) NOT NULL,
  `Arn` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Name` varchar(100) NOT NULL,
  `QueueType` varchar(20) NOT NULL,
  `UpdateTimestamp` datetime NOT NULL,
  UNIQUE KEY `listQueues_Id_IDX` (`Id`,`Name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.listRoutingProfiles definition

CREATE TABLE `listRoutingProfiles` (
  `Id` varchar(100) NOT NULL,
  `Arn` varchar(250) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `UpdateTimestamp` datetime NOT NULL,
  UNIQUE KEY `listAgents_Id_IDX` (`Id`,`Name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.queueMetrics definition

CREATE TABLE `queueMetrics` (
  `RequestTimestamp` datetime NOT NULL,
  `QueueId` varchar(100) NOT NULL,
  `AGENTS_AFTER_CONTACT_WORK` decimal(10,0) DEFAULT NULL,
  `AGENTS_AVAILABLE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ERROR` decimal(10,0) DEFAULT NULL,
  `AGENTS_NON_PRODUCTIVE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CALL` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CONTACT` decimal(10,0) DEFAULT NULL,
  `AGENTS_ONLINE` decimal(10,0) DEFAULT NULL,
  `AGENTS_STAFFED` decimal(10,0) DEFAULT NULL,
  `CONTACTS_IN_QUEUE` decimal(10,0) DEFAULT NULL,
  `CONTACTS_SCHEDULED` decimal(10,0) DEFAULT NULL,
  `OLDEST_CONTACT_AGE` decimal(10,0) DEFAULT NULL,
  UNIQUE KEY `queueMetrics_RequestTimestamp_IDX` (`RequestTimestamp`,`QueueId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.queueMetrics_external definition

CREATE TABLE `queueMetrics_external` (
  `RequestTimestamp` datetime NOT NULL,
  `QueueId` varchar(100) NOT NULL,
  `AGENTS_AFTER_CONTACT_WORK` decimal(10,0) DEFAULT NULL,
  `AGENTS_AVAILABLE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ERROR` decimal(10,0) DEFAULT NULL,
  `AGENTS_NON_PRODUCTIVE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CALL` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CONTACT` decimal(10,0) DEFAULT NULL,
  `AGENTS_ONLINE` decimal(10,0) DEFAULT NULL,
  `AGENTS_STAFFED` decimal(10,0) DEFAULT NULL,
  `CONTACTS_IN_QUEUE` decimal(10,0) DEFAULT NULL,
  `CONTACTS_SCHEDULED` decimal(10,0) DEFAULT NULL,
  `OLDEST_CONTACT_AGE` decimal(10,0) DEFAULT NULL,
  UNIQUE KEY `queueMetrics_RequestTimestamp_ext_IDX` (`RequestTimestamp`,`QueueId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.queueMetrics_hist definition

CREATE TABLE `queueMetrics_hist` (
  `RequestTimestamp` datetime NOT NULL,
  `QueueId` varchar(100) NOT NULL,
  `AGENTS_AFTER_CONTACT_WORK` decimal(10,0) DEFAULT NULL,
  `AGENTS_AVAILABLE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ERROR` decimal(10,0) DEFAULT NULL,
  `AGENTS_NON_PRODUCTIVE` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CALL` decimal(10,0) DEFAULT NULL,
  `AGENTS_ON_CONTACT` decimal(10,0) DEFAULT NULL,
  `AGENTS_ONLINE` decimal(10,0) DEFAULT NULL,
  `AGENTS_STAFFED` decimal(10,0) DEFAULT NULL,
  `CONTACTS_IN_QUEUE` decimal(10,0) DEFAULT NULL,
  `CONTACTS_SCHEDULED` decimal(10,0) DEFAULT NULL,
  `OLDEST_CONTACT_AGE` decimal(10,0) DEFAULT NULL,
  UNIQUE KEY `queueMetrics_RequestTimestamp_IDX` (`RequestTimestamp`,`QueueId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.userMetrics definition

CREATE TABLE `userMetrics` (
  `RequestTimestamp` datetime NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `UserArn` varchar(100) DEFAULT NULL,
  `RoutingProfileId` varchar(100) DEFAULT NULL,
  `RoutingProfileArn` varchar(100) DEFAULT NULL,
  `StatusStartTimestamp` varchar(100) DEFAULT NULL,
  `StatusArn` varchar(100) DEFAULT NULL,
  `StatusName` varchar(100) DEFAULT NULL,
  `AvailableSlotsByChannelVoice` decimal(10,0) DEFAULT NULL,
  `AvailableSlotsByChannelTask` decimal(10,0) DEFAULT NULL,
  `AvailableSlotsByChannelChat` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannelVoice` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannelTask` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannel` decimal(10,0) DEFAULT NULL,
  `ContactsContactId` varchar(100) DEFAULT NULL,
  `ContactsChannel` varchar(100) DEFAULT NULL,
  `ContactsInitiationMethod` varchar(100) DEFAULT NULL,
  `ContactsAgentContactState` varchar(100) DEFAULT NULL,
  `ContactsStateStartTimestamp` varchar(100) DEFAULT NULL,
  `ContactsConnectedToAgentTimestamp` varchar(100) DEFAULT NULL,
  `ContactsQueueId` varchar(100) DEFAULT NULL,
  `ContactsQueueArn` varchar(100) DEFAULT NULL,
  UNIQUE KEY `userMetrics_RequestTimestamp_IDX` (`RequestTimestamp`,`UserId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

```
-- awsconnectmetrics.userMetrics_hist definition

CREATE TABLE `userMetrics_hist` (
  `RequestTimestamp` datetime NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `UserArn` varchar(100) DEFAULT NULL,
  `RoutingProfileId` varchar(100) DEFAULT NULL,
  `RoutingProfileArn` varchar(100) DEFAULT NULL,
  `StatusStartTimestamp` varchar(100) DEFAULT NULL,
  `StatusArn` varchar(100) DEFAULT NULL,
  `StatusName` varchar(100) DEFAULT NULL,
  `AvailableSlotsByChannelVoice` decimal(10,0) DEFAULT NULL,
  `AvailableSlotsByChannelTask` decimal(10,0) DEFAULT NULL,
  `AvailableSlotsByChannelChat` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannelVoice` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannelTask` decimal(10,0) DEFAULT NULL,
  `MaxSlotsByChannel` decimal(10,0) DEFAULT NULL,
  `ContactsContactId` varchar(100) DEFAULT NULL,
  `ContactsChannel` varchar(100) DEFAULT NULL,
  `ContactsInitiationMethod` varchar(100) DEFAULT NULL,
  `ContactsAgentContactState` varchar(100) DEFAULT NULL,
  `ContactsStateStartTimestamp` varchar(100) DEFAULT NULL,
  `ContactsConnectedToAgentTimestamp` varchar(100) DEFAULT NULL,
  `ContactsQueueId` varchar(100) DEFAULT NULL,
  `ContactsQueueArn` varchar(100) DEFAULT NULL,
  UNIQUE KEY `userMetrics_RequestTimestamp_IDX` (`RequestTimestamp`,`UserId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```
```
CREATE TABLE `hierarchyGroup` (
  `Id` varchar(250) DEFAULT NULL,
  `Arn` varchar(250) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `LevelId` varchar(250) DEFAULT NULL,
  `LevelOneId` varchar(250) DEFAULT NULL,
  `LevelOneArn` varchar(250) DEFAULT NULL,
  `LevelOneName` varchar(250) DEFAULT NULL,
  `LevelOneLastModifiedTime` datetime DEFAULT NULL,
  `LevelOneLastModifiedRegion` varchar(250) DEFAULT NULL,
  `LevelTwoId` varchar(250) DEFAULT NULL,
  `LevelTwoArn` varchar(250) DEFAULT NULL,
  `LevelTwoName` varchar(250) DEFAULT NULL,
  `LevelTwoLastModifiedTime` datetime DEFAULT NULL,
  `LevelTwoLastModifiedRegion` varchar(250) DEFAULT NULL,
  `LevelThreeId` varchar(250) DEFAULT NULL,
  `LevelThreeArn` varchar(250) DEFAULT NULL,
  `LevelThreeName` varchar(250) DEFAULT NULL,
  `LevelThreeLastModifiedTime` datetime DEFAULT NULL,
  `LevelThreeLastModifiedRegion` varchar(250) DEFAULT NULL,
  `LevelFourId` varchar(250) DEFAULT NULL,
  `LevelFourArn` varchar(250) DEFAULT NULL,
  `LevelFourName` varchar(250) DEFAULT NULL,
  `LevelFourLastModifiedTime` datetime DEFAULT NULL,
  `LevelFourLastModifiedRegion` varchar(250) DEFAULT NULL,
  `LevelFiveId` varchar(250) DEFAULT NULL,
  `LevelFiveArn` varchar(250) DEFAULT NULL,
  `LevelFiveName` varchar(250) DEFAULT NULL,
  `LevelFiveLastModifiedTime` datetime DEFAULT NULL,
  `LevelFiveLastModifiedRegion` varchar(250) DEFAULT NULL,
  `UpdateTimestamp` datetime DEFAULT NULL,
  UNIQUE KEY `hierarchyGroup_Id_IDX` (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


# VIEW 

```
-- awsconnectmetrics.queueMetrics_external_source source

CREATE OR REPLACE
ALGORITHM = UNDEFINED VIEW `awsconnectmetrics`.`queueMetrics_external_source` AS
select
    `a`.`RequestTimestamp` AS `RequestTimestamp`,
    `b`.`Name` AS `QueueId`,
    `a`.`AGENTS_AFTER_CONTACT_WORK` AS `AGENTS_AFTER_CONTACT_WORK`,
    `a`.`AGENTS_AVAILABLE` AS `AGENTS_AVAILABLE`,
    `a`.`AGENTS_ERROR` AS `AGENTS_ERROR`,
    `a`.`AGENTS_NON_PRODUCTIVE` AS `AGENTS_NON_PRODUCTIVE`,
    `a`.`AGENTS_ON_CALL` AS `AGENTS_ON_CALL`,
    `a`.`AGENTS_ON_CONTACT` AS `AGENTS_ON_CONTACT`,
    `a`.`AGENTS_ONLINE` AS `AGENTS_ONLINE`,
    `a`.`AGENTS_STAFFED` AS `AGENTS_STAFFED`,
    `a`.`CONTACTS_IN_QUEUE` AS `CONTACTS_IN_QUEUE`,
    `a`.`CONTACTS_SCHEDULED` AS `CONTACTS_SCHEDULED`,
    `a`.`OLDEST_CONTACT_AGE` AS `OLDEST_CONTACT_AGE`
from
    (`awsconnectmetrics`.`queueMetrics` `a`
left join `awsconnectmetrics`.`listQueues` `b` on
    ((`a`.`QueueId` = `b`.`Id`)))
where
    (`a`.`RequestTimestamp` = (
    select
        max(`awsconnectmetrics`.`queueMetrics`.`RequestTimestamp`)
    from
        `awsconnectmetrics`.`queueMetrics`));

Error Code: 1064. You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7

```

# EVENT


```
DELIMITER $$

CREATE EVENT mv_queues_to_hist
ON SCHEDULE EVERY 1 DAY
STARTS '2024-01-05 01:00:00.000'
ON COMPLETION NOT PRESERVE
ENABLE
DO BEGIN 
	INSERT INTO queueMetrics_hist SELECT * FROM queueMetrics WHERE DATE(RequestTimestamp) < (CURRENT_DATE);
	DELETE FROM queueMetrics WHERE DATE(RequestTimestamp) < (CURRENT_DATE);
END$$

DELIMITER ;

```

```
CREATE EVENT mv_users_to_hist
ON SCHEDULE EVERY 1 DAY
STARTS '2024-01-05 01:00:00.000'
ON COMPLETION NOT PRESERVE
ENABLE
DO BEGIN 
	INSERT INTO userMetrics_hist SELECT * FROM userMetrics WHERE DATE(RequestTimestamp) < (CURRENT_DATE);
	DELETE FROM userMetrics WHERE DATE(RequestTimestamp) < (CURRENT_DATE);
END;
```

# TEST EVENTS

```
{
  "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "hierarchyGroup",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
  "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "insertAgentMetric",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
  "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "insertQueueMetric",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
  "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "listAgents",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
 "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "listQueues",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
  "InstanceId": "e7dbe8a6-c58d-4bcf-8398-78358c97c685",
  "Method": "listRoutingProfiles",
  "DatabaseName": "awsconnectmetrics"
}
```

```
{
  "Method": "queueMetricsExternal"
}
```


# STATE MACHINE

```
{
  "Comment": "A description of my state machine",
  "StartAt": "Queue Lambda (1)",
  "States": {
    "Queue Lambda (1)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertQueueMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Agent Lambda (1)"
    },
    "Agent Lambda (1)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertAgentMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Wait"
    },
    "Wait": {
      "Type": "Wait",
      "Seconds": 12,
      "Next": "Queue Lambda (2)"
    },
    "Queue Lambda (2)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertQueueMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Agent Lambda (2)"
    },
    "Agent Lambda (2)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertAgentMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Wait (1)"
    },
    "Wait (1)": {
      "Type": "Wait",
      "Seconds": 12,
      "Next": "Queue Lambda (3)"
    },
    "Queue Lambda (3)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertQueueMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Agent Lambda"
    },
    "Agent Lambda": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertAgentMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Wait (2)"
    },
    "Wait (2)": {
      "Type": "Wait",
      "Seconds": 12,
      "Next": "Queue Lambda"
    },
    "Queue Lambda": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertQueueMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Agent Lambda (3)"
    },
    "Agent Lambda (3)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertAgentMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Wait (3)"
    },
    "Wait (3)": {
      "Type": "Wait",
      "Seconds": 12,
      "Next": "Queue Lambda (4)"
    },
    "Queue Lambda (4)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertQueueMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Agent Lambda (4)"
    },
    "Agent Lambda (4)": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-west-2:682333202436:function:get-queue-to-mysql:$LATEST",
        "Payload": {
          "InstanceId": "ee1a845e-22c8-4856-9a92-4980017b5d11",
          "Method": "insertAgentMetric",
          "DatabaseName": "awsconnectmetrics"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "End": true
    }
  }
}
```



```
select b.Username, b.Firstname, b.Lastname,c.Name as RoutingProfileName, a.*, d.Name as QueueName
from userMetrics a
left join listAgents b on a.UserId = b.Id
left join listRoutingProfiles c on a.RoutingProfileId = c.Id
left outer join listQueues d on a.ContactsQueueId = d.Id
where a.RequestTimestamp = (select max(RequestTimestamp) from userMetrics)
```


```
select b.Name, a.*
from queueMetrics a
left join listQueues b on a.QueueId = b.Id
where a.RequestTimestamp = (select max(RequestTimestamp) from queueMetrics)
```


```
concat(

ifelse({OLDEST_CONTACT_AGE} / 3600 < 10,concat('0',tostring(floor({OLDEST_CONTACT_AGE} / 3600))),tostring(floor({OLDEST_CONTACT_AGE} / 3600)))

,':',

ifelse(({OLDEST_CONTACT_AGE} % 3600)/60 < 10,concat('0',tostring(floor(({OLDEST_CONTACT_AGE} % 3600)/60))),tostring(floor(({OLDEST_CONTACT_AGE} % 3600)/60)))

,':',

ifelse({OLDEST_CONTACT_AGE} % 60 < 10,concat('0',tostring(floor({OLDEST_CONTACT_AGE} % 60))),tostring(floor({OLDEST_CONTACT_AGE} % 60)))

)
```

```
ifelse(ContactsAgentContactState = "0", {Duration(hms)}, {connectedDuration(hms)}  )
```


```
dateDiff(StatusStartTimestamp,now(),"SS")
```

```
dateDiff(ContactsConnectedToAgentTimestamp,now(),"SS")
```

```
concat(

ifelse(connectedDuration / 3600 < 10,concat('0',tostring(floor(connectedDuration / 3600))),tostring(floor(connectedDuration / 3600)))

,':',

ifelse((connectedDuration % 3600)/60 < 10,concat('0',tostring(floor((connectedDuration % 3600)/60))),tostring(floor((connectedDuration % 3600)/60)))

,':',

ifelse(connectedDuration % 60 < 10,concat('0',tostring(floor(connectedDuration % 60))),tostring(floor(connectedDuration % 60)))

)
```

```
// Import necessary AWS SDK clients and commands for Athena
const { AthenaClient, StartQueryExecutionCommand, GetQueryExecutionCommand, GetQueryResultsCommand } = require("@aws-sdk/client-athena");

// Import mysql2/promise
const mysql = require('mysql2/promise');

// Initialize Athena client
const athenaClient = new AthenaClient({ region: "your-region" });

// MySQL connection settings
const mysqlConnectionConfig = {
    host: 'your-mysql-host',
    user: 'your-mysql-user',
    password: 'your-mysql-password',
    database: 'your-mysql-database'
};

// Function to execute Athena query and return results
async function executeAthenaQuery() {
    const params = {
        QueryString: `SELECT SUBSTR(queue.arn,92,36) as queueId, count(*) as TotalCalls, count_if(agent is null) as TotalAbandoned
                        FROM "cdtfaconnectqactr"."connect_ctr" 
                        WHERE queue is not null 
                        AND queue.arn not like '%agent%'
                        AND year = CAST(format_datetime(now(),'y') AS INT)
                        AND month = CAST(format_datetime(now(),'M') AS INT)
                        AND day = CAST(format_datetime(now(),'d') AS INT)
                        GROUP BY 1`,
        QueryExecutionContext: {
            Database: "your-database-name"
        },
        ResultConfiguration: {
            OutputLocation: "s3://your-bucket-name/path/to/query/results/"
        }
    };

    // Start query execution
    const startQueryExecutionResponse = await athenaClient.send(new StartQueryExecutionCommand(params));
    const queryExecutionId = startQueryExecutionResponse.QueryExecutionId;

    // Wait for query execution to complete
    let status = "RUNNING";
    while (status === "RUNNING" || status === "QUEUED") {
        const queryExecutionResponse = await athenaClient.send(new GetQueryExecutionCommand({ QueryExecutionId: queryExecutionId }));
        status = queryExecutionResponse.QueryExecution.Status.State;
        if (status === "FAILED" || status === "CANCELLED") {
            throw new Error(`Query failed or was cancelled: ${queryExecutionResponse.QueryExecution.Status.StateChangeReason}`);
        }
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second before checking again
    }

    // Fetch query results
    const queryResultsResponse = await athenaClient.send(new GetQueryResultsCommand({ QueryExecutionId: queryExecutionId }));
    return queryResultsResponse.ResultSet.Rows;
}

// Function to update the queueMetrics_external table
async function updateDatabase(queueId, totalCalls, abandonedCalls) {
    // Connect to MySQL database
    const connection = await mysql.createConnection(mysqlConnectionConfig);
    
    // Prepare and execute the update query
    const sql = `UPDATE queueMetrics_external SET TotalCalls = ?, AbandonedCalls = ? WHERE QueueId = ?`;
    const [results] = await connection.execute(sql, [totalCalls, abandonedCalls, queueId]);

    console.log(`Updated database for QueueId: ${queueId}. Rows affected: ${results.affectedRows}`);
    
    // Close the connection
    await connection.end();
}

(async () => {
    try {
        const queryResults = await executeAthenaQuery();
        for (const row of queryResults.slice(1)) { // Skip header row
            const queueId = row.Data[0].VarCharValue;
            const totalCalls = parseInt(row.Data[1].VarCharValue, 10);
            const abandonedCalls = parseInt(row.Data[2].VarCharValue, 10);

            await updateDatabase(queueId, totalCalls, abandonedCalls);
        }
    } catch (error) {
        console.error("An error occurred:", error);
    }
})();

```
Hawaii Events:

DELIMITER $$

DROP EVENT IF EXISTS mv_users_to_hist $$

CREATE EVENT mv_users_to_hist
ON SCHEDULE
  EVERY 1 DAY
  STARTS '2024-01-05 01:00:00'
ON COMPLETION NOT PRESERVE
ENABLE
DO
BEGIN
  -- Force Hawaii Time for date calculation
  SET time_zone = 'Pacific/Honolulu';

  -- Move records older than Hawaii "today"
  INSERT INTO userMetrics_hist
  SELECT *
  FROM userMetrics
  WHERE RequestTimestamp < CONVERT_TZ(CURRENT_DATE, 'Pacific/Honolulu', 'UTC');

  DELETE FROM userMetrics
  WHERE RequestTimestamp < CONVERT_TZ(CURRENT_DATE, 'Pacific/Honolulu', 'UTC');
END$$

DELIMITER ;
