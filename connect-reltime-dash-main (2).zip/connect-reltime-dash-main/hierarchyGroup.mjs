// runtime: nodejs20.x or 22.x
// env:
//   SECRET_NAME = your RDS credentials secret
//   HOST        = RDS endpoint
//   DATABASE    = awsconnectmetrics (or whatever your DB is)

import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { ConnectClient, DescribeUserHierarchyGroupCommand } from "@aws-sdk/client-connect";
import mysql from "mysql2/promise";

const secretName = process.env.SECRET_NAME;
const host = process.env.HOST;
const database = process.env.DATABASE;

const secretsManagerClient = new SecretsManagerClient({});
const connectClient = new ConnectClient({});

// ---- Helpers ----

// Convert anything (ISO string, millis, seconds, Date) → MySQL DATETIME "YYYY-MM-DD HH:MM:SS" or null
const toMysqlDatetime = (value) => {
  if (value === undefined || value === null) return null;

  let d;

  if (value instanceof Date) {
    d = value;
  } else {
    const num = Number(value);
    if (!Number.isNaN(num)) {
      // crude heuristic: millis vs seconds
      if (num > 1e11) {
        d = new Date(num); // epoch millis
      } else if (num > 1e9) {
        d = new Date(num * 1000); // epoch seconds
      } else {
        d = new Date(num); // fallback
      }
    } else {
      d = new Date(value); // ISO string like "2025-06-26T01:52:31.692Z"
    }
  }

  if (isNaN(d.getTime())) return null;

  const pad = (n) => String(n).padStart(2, "0");

  // Using UTC for consistency; switch to local if you prefer
  const year = d.getUTCFullYear();
  const month = pad(d.getUTCMonth() + 1);
  const day = pad(d.getUTCDate());
  const hours = pad(d.getUTCHours());
  const minutes = pad(d.getUTCMinutes());
  const seconds = pad(d.getUTCSeconds());

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// Build values for a level (LevelOne, LevelTwo, etc.) in the exact order of your table:
//   Id, Arn, Name, LastModifiedTime, LastModifiedRegion
const buildLevelValues = (hierarchyPath, levelKey) => {
  const info = (hierarchyPath && hierarchyPath[levelKey]) || {};
  return [
    info.Id ?? null,
    info.Arn ?? null,
    info.Name ?? null,
    toMysqlDatetime(info.LastModifiedTime),
    info.LastModifiedRegion ?? null,
  ];
};

export const hierarchyGroup = async (event) => {
  console.log("Event received:", JSON.stringify(event));

  // ---- Secrets / DB config ----
  let secretResponse;
  try {
    secretResponse = await secretsManagerClient.send(
      new GetSecretValueCommand({
        SecretId: secretName,
        VersionStage: "AWSCURRENT",
      })
    );
  } catch (error) {
    console.error("Error fetching secret from Secrets Manager:", error);
    throw error;
  }

  const connectionSettings = JSON.parse(secretResponse.SecretString);
  const dbUser = connectionSettings.username;
  const dbPassword = connectionSettings.password;

  const connectionConfig = {
    host,
    user: dbUser,
    password: dbPassword,
    database,
  };

  const insertQuery = `
    INSERT INTO hierarchyGroup (
      Id,
      Arn,
      Name,
      LevelId,
      LevelOneId,
      LevelOneArn,
      LevelOneName,
      LevelOneLastModifiedTime,
      LevelOneLastModifiedRegion,
      LevelTwoId,
      LevelTwoArn,
      LevelTwoName,
      LevelTwoLastModifiedTime,
      LevelTwoLastModifiedRegion,
      LevelThreeId,
      LevelThreeArn,
      LevelThreeName,
      LevelThreeLastModifiedTime,
      LevelThreeLastModifiedRegion,
      LevelFourId,
      LevelFourArn,
      LevelFourName,
      LevelFourLastModifiedTime,
      LevelFourLastModifiedRegion,
      LevelFiveId,
      LevelFiveArn,
      LevelFiveName,
      LevelFiveLastModifiedTime,
      LevelFiveLastModifiedRegion,
      UpdateTimestamp
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `;

  let connection;

  try {
    connection = await mysql.createConnection(connectionConfig);
    console.log("Connected to MySQL:", { host, database, user: dbUser });

    // Start from a clean slate each run
    await connection.query("TRUNCATE TABLE hierarchyGroup");
    console.log("Truncated hierarchyGroup table");

    // Get distinct hierarchy groups from listAgents
    const [results] = await connection.query(
      "SELECT DISTINCT HierarchyGroupId FROM listAgents"
    );
    console.log("Distinct HierarchyGroupIds:", results);

    let firstDebugPrinted = false;

    for (const result of results) {
      if (!result.HierarchyGroupId) {
        console.warn("Skipping row with empty HierarchyGroupId:", result);
        continue;
      }

      const params = {
        HierarchyGroupId: result.HierarchyGroupId,
        InstanceId: event.InstanceId,
      };

      console.log("Calling DescribeUserHierarchyGroup with:", params);

      let response;
      try {
        const describeCommand = new DescribeUserHierarchyGroupCommand(params);
        response = await connectClient.send(describeCommand);
      } catch (err) {
        console.error(
          "Error calling DescribeUserHierarchyGroup for",
          result.HierarchyGroupId,
          err
        );
        continue;
      }

      const hierarchyGroupInfo = response.HierarchyGroup;
      if (!hierarchyGroupInfo) {
        console.warn("No HierarchyGroup in response for", result.HierarchyGroupId);
        continue;
      }

      if (!firstDebugPrinted) {
        console.log(
          "Sample HierarchyGroup from Connect:",
          JSON.stringify(hierarchyGroupInfo, null, 2)
        );
        firstDebugPrinted = true;
      }

      const hierarchyPath = hierarchyGroupInfo.HierarchyPath || {};

      const levelOneValues = buildLevelValues(hierarchyPath, "LevelOne");
      const levelTwoValues = buildLevelValues(hierarchyPath, "LevelTwo");
      const levelThreeValues = buildLevelValues(hierarchyPath, "LevelThree");
      const levelFourValues = buildLevelValues(hierarchyPath, "LevelFour");
      const levelFiveValues = buildLevelValues(hierarchyPath, "LevelFive");

      const insertValues = [
        hierarchyGroupInfo.Id ?? null,        // Id
        hierarchyGroupInfo.Arn ?? null,       // Arn
        hierarchyGroupInfo.Name ?? null,      // Name
        hierarchyGroupInfo.LevelId ?? null,   // LevelId
        ...levelOneValues,
        ...levelTwoValues,
        ...levelThreeValues,
        ...levelFourValues,
        ...levelFiveValues,
        toMysqlDatetime(new Date()),          // UpdateTimestamp
      ];

      console.log("Insert values length:", insertValues.length);
      console.log("Insert values sample:", JSON.stringify(insertValues));

      if (insertValues.length !== 30) {
        console.error(
          "❌ insertValues length mismatch (expected 30):",
          insertValues.length
        );
      }

      if (insertValues.includes(undefined)) {
        console.error("❌ Undefined value detected in insertValues", insertValues);
      }

      try {
        await connection.execute(insertQuery, insertValues);
        console.log("✅ Inserted hierarchyGroup row for", hierarchyGroupInfo.Id);
      } catch (err) {
        console.error(
          "❌ MySQL insert error for HierarchyGroup",
          hierarchyGroupInfo.Id,
          err
        );
        // keep going even if one row fails
      }
    }

    console.log("Done processing hierarchy groups.");
  } catch (error) {
    console.error("Top-level error in hierarchyGroup Lambda:", error);
    throw error;
  } finally {
    if (connection) {
      await connection.end();
      console.log("Closed MySQL connection");
    }
  }

  return { status: "ok" };
};
