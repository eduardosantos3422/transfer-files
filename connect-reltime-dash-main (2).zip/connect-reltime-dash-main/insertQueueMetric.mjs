import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { ConnectClient, ListQueuesCommand, GetCurrentMetricDataCommand } from "@aws-sdk/client-connect";
import mysql from "mysql2/promise";

const secretName = process.env.SECRET_NAME;
const host = process.env.HOST;
const database = process.env.DATABASE;

const secretsManagerClient = new SecretsManagerClient({});
let secretResponse;

try {
  secretResponse = await secretsManagerClient.send(
    new GetSecretValueCommand({
      SecretId: secretName,
      VersionStage: "AWSCURRENT",
    })
  );
} catch (error) {
  console.error(`Error fetching secret: ${error}`);
  throw error;
}

const connectionSettings = JSON.parse(secretResponse.SecretString);
const secret = connectionSettings.password;
const user = connectionSettings.username;

const connectClient = new ConnectClient({});

export const insertQueueMetric = async (event) => {
  const connectionConfig = {
    host,
    user,
    password: secret,
    database,
  };

  try {
    const instanceId = event.InstanceId;
    let queueIds = [];

    const listQueuesParams = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      MaxResults: 1000,
    };

    const listQueuesCommand = new ListQueuesCommand(listQueuesParams);
    const listQueuesResponse = await connectClient.send(listQueuesCommand);
    const queues = listQueuesResponse.QueueSummaryList;

    for (let queue of queues) {
      queueIds.push(queue.Id);
    }

    const metricParams = {
      InstanceId: instanceId,
      CurrentMetrics: [
        { Name: "AGENTS_AFTER_CONTACT_WORK", Unit: "COUNT" },
        { Name: "AGENTS_AVAILABLE", Unit: "COUNT" },
        { Name: "AGENTS_ERROR", Unit: "COUNT" },
        { Name: "AGENTS_NON_PRODUCTIVE", Unit: "COUNT" },
        { Name: "AGENTS_ON_CALL", Unit: "COUNT" },
        { Name: "AGENTS_ON_CONTACT", Unit: "COUNT" },
        { Name: "AGENTS_ONLINE", Unit: "COUNT" },
        { Name: "AGENTS_STAFFED", Unit: "COUNT" },
        { Name: "CONTACTS_IN_QUEUE", Unit: "COUNT" },
        { Name: "CONTACTS_SCHEDULED", Unit: "COUNT" },
        { Name: "OLDEST_CONTACT_AGE", Unit: "SECONDS" },
      ],
      Filters: {
        Queues: queueIds,
        Channels: ["VOICE"],
      },
      Groupings: ["QUEUE"],
    };

    const getCurrentMetricDataCommand = new GetCurrentMetricDataCommand(metricParams);
    const metricData = await connectClient.send(getCurrentMetricDataCommand);
    console.log(`metricData: ${JSON.stringify(metricData)}`);

    const metricResults = metricData.MetricResults;

    const connection = await mysql.createConnection(connectionConfig);

    let query =
      "INSERT INTO queueMetrics (RequestTimestamp, QueueId, AGENTS_AFTER_CONTACT_WORK, AGENTS_AVAILABLE, AGENTS_ERROR, AGENTS_NON_PRODUCTIVE, AGENTS_ON_CALL, AGENTS_ON_CONTACT, AGENTS_ONLINE, AGENTS_STAFFED, CONTACTS_IN_QUEUE, CONTACTS_SCHEDULED, OLDEST_CONTACT_AGE) VALUES ";

    let allValues = [];

    if (!metricResults || metricResults.length === 0) {
      return "No metric data found";
    }

    for (const result of metricResults) {
      let rowValues = [new Date(), result.Dimensions.Queue.Id];

      for (const metric of [
        "AGENTS_AFTER_CONTACT_WORK",
        "AGENTS_AVAILABLE",
        "AGENTS_ERROR",
        "AGENTS_NON_PRODUCTIVE",
        "AGENTS_ON_CALL",
        "AGENTS_ON_CONTACT",
        "AGENTS_ONLINE",
        "AGENTS_STAFFED",
        "CONTACTS_IN_QUEUE",
        "CONTACTS_SCHEDULED",
        "OLDEST_CONTACT_AGE",
      ]) {
        const collection = result.Collections.find((col) => col.Metric.Name === metric);
        rowValues.push(collection ? collection.Value : 0);
      }

      allValues.push(rowValues);
    }

    const valuePlaceholders = allValues.map(() => "(?)").join(",");
    query += valuePlaceholders;

    console.log(`Inserting data: ${JSON.stringify(allValues)}`);
    await connection.query(query, allValues);
    await connection.end();

    return "Data successfully inserted.";
  } catch (error) {
    console.error(`Error: ${error}`);
    throw error;
  }
};
