import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { ConnectClient, ListQueuesCommand } from "@aws-sdk/client-connect";
import mysql from "mysql2/promise";

const secretName = process.env.SECRET_NAME;
const host = process.env.HOST;
const database = process.env.DATABASE;

const secretsManagerClient = new SecretsManagerClient({});
let secretResponse;

try {
  secretResponse = await secretsManagerClient.send(
    new GetSecretValueCommand({
      SecretId: secretName,
      VersionStage: "AWSCURRENT",
    })
  );
} catch (error) {
  console.error(`Error fetching secret: ${error}`);
  throw error;
}

const connectionSettings = JSON.parse(secretResponse.SecretString);
const secret = connectionSettings.password;
const user = connectionSettings.username;

const connectClient = new ConnectClient({});

export const listQueues = async (event) => {
  const connectionConfig = {
    host,
    user,
    password: secret,
    database,
  };

  try {
    const instanceId = event.InstanceId;
    const listQueuesParams = {
      InstanceId: instanceId,
      QueueTypes: ["STANDARD"],
      MaxResults: 1000,
    };

    const connection = await mysql.createConnection(connectionConfig);

    const truncateQuery = "TRUNCATE TABLE listQueues";
    await connection.query(truncateQuery);

    const listQueuesCommand = new ListQueuesCommand(listQueuesParams);
    const listQueuesResponse = await connectClient.send(listQueuesCommand);
    const results = listQueuesResponse.QueueSummaryList;

    const insertQuery =
      "INSERT INTO listQueues (Id, Arn, Name, QueueType, UpdateTimestamp) VALUES (?,?,?,?,?)";

    for (let result of results) {
      const insertValues = [
        result.Id || null,
        result.Arn || null,
        result.Name || null,
        result.QueueType || null,
        new Date(),
      ];

      console.log(`Inserting data: ${JSON.stringify(insertValues)}`);

      if (insertValues.includes(undefined)) {
        console.error("Undefined value detected in insertValues", insertValues);
        continue;
      }

      await connection.execute(insertQuery, insertValues);
    }

    await connection.end();
  } catch (error) {
    console.error(`Error: ${error}`);
    throw error;
  }
};
