import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { ConnectClient, ListUsersCommand, DescribeUserCommand } from "@aws-sdk/client-connect";
import mysql from "mysql2/promise";

const secretName = process.env.SECRET_NAME;
const host = process.env.HOST; 
const database = process.env.DATABASE;

const client = new SecretsManagerClient({});
let response;

try {
  response = await client.send(
    new GetSecretValueCommand({
      SecretId: secretName,
      VersionStage: "AWSCURRENT",
    })
  );
} catch (error) {
  console.log(`Error: ${error}`);
  throw error;
}

const connectionSetting = JSON.parse(response.SecretString);

const secret = connectionSetting.password;

const user = connectionSetting.username;

const connectClient = new ConnectClient({});

export const listAgents = async (event) => {
  const connectionConfig = {
    host,
    user,
    password: secret,
    database
  };

  try {
    const instanceId = event.InstanceId;
    const listUsersParams = {
      InstanceId: instanceId,
      MaxResults: 1000,
    };

    const connection = await mysql.createConnection(connectionConfig);

    const listUsersCommand = new ListUsersCommand(listUsersParams);
    const listUsersResponse = await connectClient.send(listUsersCommand);
    const results = listUsersResponse.UserSummaryList;

    let query = "TRUNCATE TABLE listAgents";
    await connection.query(query);


    query = "INSERT INTO listAgents (Id, Arn, Username, Firstname, Lastname, RoutingProfileId, HierarchyGroupId, UpdateTimestamp) VALUES (?,?,?,?,?,?,?,?)";

    for (let result of results) {
      const describeUserParams = {
        InstanceId: instanceId,
        UserId: result.Id,
      };

      const describeUserCommand = new DescribeUserCommand(describeUserParams);
      const describeUserResponse = await connectClient.send(describeUserCommand);

      const insertValues = [
        result.Id || null,
        result.Arn || null,
        result.Username || null,
        describeUserResponse?.User?.IdentityInfo?.FirstName || null,
        describeUserResponse?.User?.IdentityInfo?.LastName || null,
        describeUserResponse?.User?.RoutingProfileId || null,
        describeUserResponse?.User?.HierarchyGroupId || null,
        new Date(),
      ];

      console.log(`Inserting data: ${JSON.stringify(insertValues)}`);

      if (insertValues.includes(undefined)) {
        console.error("Undefined value detected in insertValues", insertValues);
        continue;
      }

      await connection.execute(query, insertValues);
    }

    await connection.end();
  } catch (error) {
    console.log(`Error: ${error}`);
    throw error;
  }
};
